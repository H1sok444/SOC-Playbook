import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Shield, AlertTriangle, Search, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import './App.css';

// Données des directives OSSIM
const directives = [
  {
    id: 'dos_dns_server',
    name: 'DoS Attack on DNS Server',
    description: 'Delivery & Attack, Denial of Service - Resource exhaustion, Attack',
    priority: 3,
    sids: [1, 2, 1040, 1008, 1009],
    category: 'denial_of_service',
    icon: AlertTriangle,
    color: 'bg-red-500'
  },
  {
    id: 'ipv4_scan',
    name: 'Scan Attack IPv4 Scan',
    description: 'Reconnaissance & Probing, Portscan, Scan',
    priority: 3,
    sids: [1006, 1007],
    category: 'reconnaissance',
    icon: Search,
    color: 'bg-orange-500'
  },
  {
    id: 'ips_traffic',
    name: 'IPS Traffic Detected',
    description: 'Delivery & Attack, Suspicious Behaviour, Attack',
    priority: 5,
    sids: [1039],
    category: 'intrusion_prevention',
    icon: Activity,
    color: 'bg-yellow-500'
  }
];

// Playbooks détaillés
const playbooks = {
  dos_dns_server: {
    title: 'Playbook SOC: Attaque DoS sur serveur DNS',
    description: 'Une attaque par déni de service (DoS) sur un serveur DNS vise à rendre le service DNS indisponible en le submergeant de trafic malveillant.',
    steps: [
      {
        phase: 'Détection et Vérification',
        actions: [
          'Vérifier les alertes générées par les SIDs associés (1, 2, 1040, 1008, 1009)',
          'Analyser les logs du serveur DNS et le trafic réseau',
          'Vérifier la disponibilité du service DNS'
        ]
      },
      {
        phase: 'Contention',
        actions: [
          'Isoler le serveur DNS attaqué si possible',
          'Mettre en place des règles de filtrage au niveau du pare-feu',
          'Appliquer des limitations de débit sur le trafic DNS',
          'Activer les protections anti-DDoS si disponibles'
        ]
      },
      {
        phase: 'Éradication',
        actions: [
          'Supprimer toute configuration malveillante',
          'Mettre à jour le serveur DNS et les systèmes de sécurité'
        ]
      },
      {
        phase: 'Récupération',
        actions: [
          'Rétablir le service DNS',
          'Maintenir une surveillance accrue'
        ]
      },
      {
        phase: 'Post-Incident',
        actions: [
          'Documenter l\'incident et les leçons apprises',
          'Améliorer les défenses préventives',
          'Informer les parties prenantes'
        ]
      }
    ]
  },
  ipv4_scan: {
    title: 'Playbook SOC: Scan Attack IPv4 Scan',
    description: 'Un scan IPv4 est une activité de reconnaissance où un attaquant tente d\'identifier les hôtes actifs et les ports ouverts sur un réseau.',
    steps: [
      {
        phase: 'Détection et Analyse',
        actions: [
          'Confirmer les alertes générées par les SIDs (1006, 1007)',
          'Identifier l\'adresse IP source du scan',
          'Déterminer les adresses IP cibles',
          'Analyser le type de scan et les ports ciblés',
          'Vérifier la légitimité de l\'activité'
        ]
      },
      {
        phase: 'Contention',
        actions: [
          'Bloquer l\'adresse IP source si malveillante',
          'Isoler les systèmes compromis si nécessaire'
        ]
      },
      {
        phase: 'Éradication',
        actions: [
          'Corriger les vulnérabilités identifiées',
          'Nettoyer les systèmes compromis'
        ]
      },
      {
        phase: 'Récupération',
        actions: [
          'Rétablir les services affectés',
          'Maintenir une surveillance accrue'
        ]
      },
      {
        phase: 'Post-Incident',
        actions: [
          'Documenter l\'incident',
          'Améliorer les défenses du réseau',
          'Mettre à jour les règles de détection'
        ]
      }
    ]
  },
  ips_traffic: {
    title: 'Playbook SOC: Trafic Détecté par IPS',
    description: 'Un système de prévention d\'intrusion (IPS) a détecté et potentiellement bloqué du trafic réseau malveillant ou suspect.',
    steps: [
      {
        phase: 'Détection et Vérification',
        actions: [
          'Examiner les détails de l\'alerte générée par le SID 1039',
          'Consulter les logs de l\'IPS pour plus de contexte',
          'Analyser le trafic réseau autour de l\'heure de l\'alerte',
          'Vérifier les systèmes cibles pour détecter toute activité suspecte'
        ]
      },
      {
        phase: 'Contention',
        actions: [
          'Confirmer que l\'IPS a correctement bloqué le trafic',
          'Isoler les systèmes compromis si nécessaire',
          'Mettre à jour les règles IPS/pare-feu'
        ]
      },
      {
        phase: 'Éradication',
        actions: [
          'Supprimer tout logiciel malveillant',
          'Corriger les vulnérabilités exploitées'
        ]
      },
      {
        phase: 'Récupération',
        actions: [
          'Rétablir les services et systèmes affectés',
          'Maintenir une surveillance renforcée'
        ]
      },
      {
        phase: 'Post-Incident',
        actions: [
          'Documenter l\'incident et les leçons apprises',
          'Renforcer les défenses',
          'Partager les informations sur la menace'
        ]
      }
    ]
  }
};

// Composant pour la page d'accueil
function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <div className="flex justify-center items-center mb-4">
            <Shield className="h-12 w-12 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">SOC Playbooks</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Playbooks de réponse aux incidents pour les directives OSSIM. 
            Chaque playbook fournit des étapes détaillées pour gérer efficacement les alertes de sécurité.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {directives.map((directive) => {
            const IconComponent = directive.icon;
            return (
              <Card key={directive.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className={`p-3 rounded-lg ${directive.color}`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <Badge variant="outline">Priorité {directive.priority}</Badge>
                  </div>
                  <CardTitle className="text-lg">{directive.name}</CardTitle>
                  <CardDescription>{directive.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {directive.sids.map((sid) => (
                      <Badge key={sid} variant="secondary">SID {sid}</Badge>
                    ))}
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={() => window.location.href = `#/playbook/${directive.id}`}
                  >
                    Voir le Playbook
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-semibold mb-4">Architecture Évolutive</h2>
          <p className="text-gray-600 mb-4">
            Cette plateforme est conçue pour être facilement extensible. De nouveaux types de directives 
            et leurs playbooks associés peuvent être ajoutés simplement en étendant la structure de données existante.
          </p>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Shield className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <h3 className="font-semibold">Modulaire</h3>
              <p className="text-sm text-gray-600">Composants réutilisables</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <Activity className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <h3 className="font-semibold">Évolutif</h3>
              <p className="text-sm text-gray-600">Ajout facile de nouveaux playbooks</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Search className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <h3 className="font-semibold">Standardisé</h3>
              <p className="text-sm text-gray-600">Structure cohérente</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Composant pour afficher un playbook spécifique
function PlaybookPage({ playbookId }) {
  const directive = directives.find(d => d.id === playbookId);
  const playbook = playbooks[playbookId];

  if (!directive || !playbook) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Playbook non trouvé</h1>
          <Button onClick={() => window.location.href = '#/'}>
            Retour à l'accueil
          </Button>
        </div>
      </div>
    );
  }

  const IconComponent = directive.icon;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                onClick={() => window.location.href = '#/'}
                className="mr-4"
              >
                ← Retour
              </Button>
              <div className={`p-3 rounded-lg ${directive.color} mr-4`}>
                <IconComponent className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{directive.name}</h1>
                <p className="text-gray-600">{directive.description}</p>
              </div>
            </div>
            <Badge variant="outline">Priorité {directive.priority}</Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Informations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-sm text-gray-500 uppercase tracking-wide">SIDs Associés</h4>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {directive.sids.map((sid) => (
                        <Badge key={sid} variant="secondary">SID {sid}</Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-gray-500 uppercase tracking-wide">Catégorie</h4>
                    <p className="mt-1 capitalize">{directive.category.replace('_', ' ')}</p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm text-gray-500 uppercase tracking-wide">Priorité</h4>
                    <p className="mt-1">{directive.priority}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <CardTitle>{playbook.title}</CardTitle>
                <CardDescription>{playbook.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {playbook.steps.map((step, index) => (
                    <div key={index} className="border-l-4 border-blue-500 pl-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-3">
                        {index + 1}. {step.phase}
                      </h3>
                      <ul className="space-y-2">
                        {step.actions.map((action, actionIndex) => (
                          <li key={actionIndex} className="flex items-start">
                            <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                            <span className="text-gray-700">{action}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// Composant principal de l'application
function App() {
  const [currentPath, setCurrentPath] = React.useState(window.location.hash.slice(1) || '/');

  React.useEffect(() => {
    const handleHashChange = () => {
      setCurrentPath(window.location.hash.slice(1) || '/');
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderPage = () => {
    if (currentPath === '/') {
      return <HomePage />;
    }
    
    const playbookMatch = currentPath.match(/^\/playbook\/(.+)$/);
    if (playbookMatch) {
      return <PlaybookPage playbookId={playbookMatch[1]} />;
    }

    return <HomePage />;
  };

  return renderPage();
}

export default App;

