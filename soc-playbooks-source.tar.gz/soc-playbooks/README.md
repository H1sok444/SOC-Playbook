# SOC Playbooks - OSSIM Directives

## Description

Ce projet est un site web React qui héberge des playbooks SOC (Security Operations Center) pour les directives OSSIM. Il fournit des procédures détaillées de réponse aux incidents pour chaque type d'alarme détectée.

## Fonctionnalités

### Directives OSSIM Supportées

1. **DoS Attack on DNS Server** (SIDs: 1, 2, 1040, 1008, 1009)
   - Priorité 3
   - Catégorie: Denial of Service

2. **Scan Attack IPv4 Scan** (SIDs: 1006, 1007)
   - Priorité 3
   - Catégorie: Reconnaissance

3. **IPS Traffic Detected** (SID: 1039)
   - Priorité 5
   - Catégorie: Intrusion Prevention

### Architecture Évolutive

Le site web est conçu pour être facilement extensible :

- **Structure modulaire** : Composants React réutilisables
- **Données centralisées** : Structure JSON standardisée pour les directives
- **Interface cohérente** : Design uniforme pour tous les playbooks
- **Navigation intuitive** : Accès facile entre les différents playbooks

## Structure du Projet

```
soc-playbooks/
├── public/
├── src/
│   ├── assets/
│   ├── components/
│   │   └── ui/          # Composants UI (shadcn/ui)
│   ├── App.jsx          # Application principale
│   ├── App.css          # Styles globaux
│   ├── index.css        # Styles de base
│   └── main.jsx         # Point d'entrée
├── index.html           # Template HTML
├── package.json         # Dépendances
└── README.md           # Ce fichier
```

## Technologies Utilisées

- **React** : Framework JavaScript pour l'interface utilisateur
- **Tailwind CSS** : Framework CSS utilitaire
- **shadcn/ui** : Composants UI modernes
- **Lucide Icons** : Icônes vectorielles
- **Vite** : Outil de build et serveur de développement

## Installation et Utilisation

### Prérequis

- Node.js (version 18 ou supérieure)
- pnpm (gestionnaire de paquets)

### Installation

```bash
cd soc-playbooks
pnpm install
```

### Développement

```bash
pnpm run dev
```

Le site sera accessible à l'adresse : http://localhost:5173

### Build de Production

```bash
pnpm run build
```

Les fichiers de production seront générés dans le dossier `dist/`.

## Ajout de Nouveaux Playbooks

Pour ajouter un nouveau type de directive et son playbook :

1. **Ajouter la directive** dans le tableau `directives` dans `App.jsx` :

```javascript
{
  id: 'nouveau_type',
  name: 'Nom de la Directive',
  description: 'Description de la directive',
  priority: 3,
  sids: [1234, 5678],
  category: 'nouvelle_categorie',
  icon: IconComponent,
  color: 'bg-purple-500'
}
```

2. **Ajouter le playbook** dans l'objet `playbooks` dans `App.jsx` :

```javascript
nouveau_type: {
  title: 'Playbook SOC: Nouveau Type',
  description: 'Description du nouveau type d\'incident',
  steps: [
    {
      phase: 'Phase 1',
      actions: [
        'Action 1',
        'Action 2'
      ]
    }
    // ... autres phases
  ]
}
```

## Structure des Playbooks

Chaque playbook suit une structure standardisée en 5 phases :

1. **Détection et Vérification/Analyse**
2. **Contention**
3. **Éradication**
4. **Récupération**
5. **Post-Incident**

## Personnalisation

### Couleurs et Thème

Les couleurs peuvent être modifiées dans `App.css` en ajustant les variables CSS personnalisées.

### Icônes

Les icônes proviennent de Lucide Icons. Pour changer une icône, importez la nouvelle icône et modifiez la propriété `icon` de la directive.

## Support et Maintenance

Ce projet est conçu pour être maintenu facilement :

- Code bien documenté et structuré
- Composants réutilisables
- Structure de données claire
- Tests intégrés (à implémenter)

## Licence

Ce projet est fourni tel quel pour usage interne SOC.

